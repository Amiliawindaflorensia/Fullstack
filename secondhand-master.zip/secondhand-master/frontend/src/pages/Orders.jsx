function Orders() {
  return (
    <div>
      <h1 className="text-2xl font-bold">Orders Page</h1>
      <p>Here, you will see a list of your orders.</p>
    </div>
  );
}

export default Orders;
