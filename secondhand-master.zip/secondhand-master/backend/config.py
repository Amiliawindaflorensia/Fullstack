class Config:
    SECRET_KEY = 'your_secret_key'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:your_password@110.239.71.90:3306/secondhand__db'

    RAJAONGKIR_API_KEY = "238b79f7eb32c654f0238208dc0dc126"
